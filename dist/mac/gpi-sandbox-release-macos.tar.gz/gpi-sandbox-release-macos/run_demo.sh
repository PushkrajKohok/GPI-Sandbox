#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./gpi_host --demo
