# GPI Plugin Example

This is a minimal example plugin for GPI Sandbox.

## Building

```bash
mkdir build && cd build
cmake ..
cmake --build .
```

## Usage

Copy the built plugin to your host's plugins directory and load it through the Plugin Store.
